# Changelog

## 9.1.0

**Implemented New Features and Enhancements**

- Add typescript support

## 9.0.0

**Implemented New Features and Enhancements**

- Updates PrimeReact to v9

**Migration Guide**

-   Update ./layout folder and ./public/layout assets

**Implemented New Features and Enhancements**

-   Upgrade to PrimeReact 9.2.2
-   Upgrade to PrimeFlex 3.3.0
-   Upgrade to Next 13.2.3
-   Update other dependencies

## 8.1.0

-   Migrate CRA to NextJS
